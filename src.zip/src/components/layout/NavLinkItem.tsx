import { NavLink } from "react-router-dom";
import { cn } from "@/utils/cn";

interface Props {
  href: string;
  label: string;
  onClick?: () => void;
  className?: string;
  activeClassName?: string;
}

/**
 * Nav link that highlights itself when its route (or a sub-route of it,
 * e.g. /shop/:categoryId under /shop) is active. Wraps react-router's
 * NavLink so active-state logic lives in one place instead of being
 * duplicated between the desktop and mobile menus.
 */
export function NavLinkItem({ href, label, onClick, className, activeClassName }: Props) {
  return (
    <NavLink
      to={href}
      onClick={onClick}
      className={({ isActive }) =>
        cn(
          className,
          isActive && "nav-link-active",
          isActive && (activeClassName ?? "text-accent")
        )
      }
    >
      {label}
    </NavLink>
  );
}
